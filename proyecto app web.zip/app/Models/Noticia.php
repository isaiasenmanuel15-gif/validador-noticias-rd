<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Noticia extends Model
{
    use HasFactory;

    protected $table = 'registros_noticias';

    protected $fillable = [
        'url_fuente',
        'veredicto',
        'es_gob_do',
        'ip_usuario',
        'fecha_analisis'
    ];
    public $timestamps = false;
}
