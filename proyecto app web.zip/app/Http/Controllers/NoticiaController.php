<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NoticiaController extends Controller
{
    public function guardar(Request $request)
{
    try {
        \Illuminate\Support\Facades\DB::table('registros_noticias')->insert([
            'url_fuente'     => $request->url_fuente,
            'veredicto'      => $request->veredicto,
            'es_gob_do'      => $request->es_gob_do,
            'ip_usuario'     => $request->ip(),
            'fecha_analisis' => now(), // <--- ESTE ES EL NOMBRE CORRECTO SEGÚN TU IMAGEN
        ]);

        return response()->json(['status' => 'success', 'message' => '¡Reporte archivado correctamente!']);
    // ... dentro de la función guardar ...
} catch (\Exception $e) {
    // Esto enviará el mensaje real (ej: "Columna no encontrada") a tu consola de Chrome
    return response()->json([
        'error' => $e->getMessage(),
        'linea' => $e->getLine()
    ], 500);
}
}

}

