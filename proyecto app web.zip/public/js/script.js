function simularAnalisis() {
    const texto = document.getElementById('noticia').value.trim();
    const resultadoDiv = document.getElementById('resultado');
    const mensajeP = document.getElementById('mensaje-resultado');

    if (texto === "") {
        alert("Ingrese el texto de la noticia y el link de la pagina.");
        return;
    }

    // Configuración visual
    resultadoDiv.style.display = "block";
    mensajeP.innerText = "Verificando integridad de la fuente...";

    setTimeout(() => {
        const regexURL = /(https?:\/\/[^\s]+)/g;
        const enlacesEncontrados = texto.match(regexURL);
        const dominioOficial = ".gob.do";

        let veredicto = "Sospechoso"; // Valor por defecto
        let esGob = 0;

       if (enlacesEncontrados) {
    // Lógica para cuando SÍ hay un link
    const linkPrincipal = enlacesEncontrados[0].toLowerCase();
    if (linkPrincipal.includes(dominioOficial)) {
        veredicto = "FUENTE VERIFICADA";
        esGob = 1;
        mensajeP.innerHTML = "<strong>FUENTE VERIFICADA:</strong> El enlace dirige a un servidor oficial.";
    } else {
        veredicto = "FUENTE NO OFICIAL";
        esGob = 0;
        mensajeP.innerHTML = "<strong>ADVERTENCIA:</strong> La fuente no pertenece al estado.";
    }
} else {
    // Lógica para cuando SOLO hay texto (SIN links)
    veredicto = "SOSPECHOSO (SIN FUENTE)";
    esGob = 0;
    mensajeP.innerHTML = "<strong>ALERTA:</strong> No se detectaron enlaces. La información no tiene fuente verificable.";
}

        // --- CONEXIÓN CON EL CUARTEL (LARAVEL) ---
        fetch('/guardar-noticia', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                url_fuente: enlacesEncontrados ? enlacesEncontrados[0] : "Texto directo",
                veredicto: veredicto,
                es_gob_do: esGob
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log("Respuesta de Laravel:", data);
        })
        .catch(error => {
            console.error("Error en la transmisión:", error);
        });

    }, 1500);
}