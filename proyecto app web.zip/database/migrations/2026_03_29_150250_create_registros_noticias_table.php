<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registros_noticias', function (Blueprint $table) {
            $table->id();
            $table->text('url_fuente')->nullable();
            $table->string('veredicto');
            $table->boolean('es_gob_do');
            $table->string('ip_usuario');
            $table->timestamp('fecha_analisis')->useCurrent();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registros_noticias');
    }
};
