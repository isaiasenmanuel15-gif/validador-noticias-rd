<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detector de Noticias Falsas - PN</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>

    <div class="main-container">
        <header class="header">
            <div class="logo-placeholder">PN</div>
            <h1>POLICÍA NACIONAL</h1>
            <h3>República Dominicana</h3>
            <p class="subtitle">Unidad de Análisis de Desinformación</p>
        </header>

        <section class="analisis-box">
            <label for="noticia">Pegue el enlace (URL) de la noticia y el comunicado:</label>
            <textarea id="noticia" placeholder="Ej: http://policianacional.gob.do/"></textarea>
            
            <button class="btn-analizar" onclick="simularAnalisis()">
                INICIAR ANÁLISIS
            </button>
        </section>

        <div id="resultado" class="resultado-oculto">
            <p id="mensaje-resultado"></p>
        </div>
    </div>
<script src="{{ asset('js/script.js') }}"></script>
</body>
</html>
